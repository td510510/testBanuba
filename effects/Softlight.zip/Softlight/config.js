"use strict";

const makeup = require("./makeup.js");

Object.assign(globalThis, makeup.m);
/* Feel free to add your custom code below */
// Sets softlight strength from 0 to 1
Softlight.strength("1")

"use strict";

const makeup = require("./makeup.js");

Object.assign(globalThis, makeup.m);
/* Feel free to add your custom code below */
// set hair color
Hair.color("0.39 0.14 0.14 0.8")

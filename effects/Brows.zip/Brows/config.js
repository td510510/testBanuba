"use strict";

const makeup = require("./makeup.js");

Object.assign(globalThis, makeup.m);
/* Feel free to add your custom code below */
Brows.color("0.172 0.125 0.105 0.732")

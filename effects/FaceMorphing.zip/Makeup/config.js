"use strict";

const makeup = require("./makeup.js");

Object.assign(globalThis, makeup.m);
/* Feel free to add your custom code below */
FaceMorph.eyes(0.6);
FaceMorph.face(0.5);
FaceMorph.nose(1);
FaceMorph.lips(1);

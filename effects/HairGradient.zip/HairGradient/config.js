"use strict";

const makeup = require("./makeup.js");

Object.assign(globalThis, makeup.m);
/* Feel free to add your custom code below */
Hair.color("0.19 0.06 0.25", "0.09 0.25 0.38")

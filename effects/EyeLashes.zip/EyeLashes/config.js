"use strict";

const makeup = require("./makeup.js");

Object.assign(globalThis, makeup.m);
/* Feel free to add your custom code below */
// set eyelashes color
Eyelashes.color("0 0 0")
// reset eyelashes color
// Eyelashes.clear()

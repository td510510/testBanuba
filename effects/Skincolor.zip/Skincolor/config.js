"use strict";

const makeup = require("./makeup.js");

Object.assign(globalThis, makeup.m);
/* Feel free to add your custom code below */
// Set skin color
Skin.color("0.8 0.6 0.1 0.4")
// Reset skin color
// Skin.clear()

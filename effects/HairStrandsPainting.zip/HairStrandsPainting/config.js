"use strict";

const makeup = require("./makeup.js");

Object.assign(globalThis, makeup.m);
/* Feel free to add your custom code below */
Hair.strands("0.80 0.40 0.40 1.0", "0.83 0.40 0.40 1.0", "0.85 0.75 0.75 1.0", "0.87 0.60 0.60 1.0", "0.99 0.65 0.65 1.0")

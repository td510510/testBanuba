"use strict";

const makeup = require("./makeup.js");

Object.assign(globalThis, makeup.m);
/* Feel free to add your custom code below */
// set eyes color
Eyes.color("0 0.2 0.8 0.64")
// reset eyes color
// Eyes.clear()

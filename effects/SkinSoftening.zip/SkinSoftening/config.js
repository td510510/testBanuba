"use strict";

const makeup = require("./makeup.js");

Object.assign(globalThis, makeup.m);
/* Feel free to add your custom code below */
// Sets skin softening strength from 0 to 1
Skin.softening.strength("1")

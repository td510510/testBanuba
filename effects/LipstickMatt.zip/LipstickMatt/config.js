"use strict";

const makeup = require("./makeup.js");

Object.assign(globalThis, makeup.m);
/* Feel free to add your custom code below */
// set lips matt color
Lips.matt("0.85 0.43 0.5 0.8")
// resets lips color
// Lips.clear()

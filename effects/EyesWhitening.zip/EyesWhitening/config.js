"use strict";

const makeup = require("./makeup.js");

Object.assign(globalThis, makeup.m);
/* Feel free to add your custom code below */

// set eyes whitening strength
Eyes.whitening.strength("1")

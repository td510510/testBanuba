"use strict";

const makeup = require("./makeup.js");

Object.assign(globalThis, makeup.m);
/* Feel free to add your custom code below */
Lips.matt("0.85 0.23 0.2 0.8");
Makeup.eyeshadow("0.6 0.5 1 0.6");
Makeup.contour("0.3 0.1 0.1 0.2");

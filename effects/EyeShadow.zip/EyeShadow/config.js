"use strict";

const makeup = require("./makeup.js");

Object.assign(globalThis, makeup.m);
/* Feel free to add your custom code below */
Makeup.eyeshadow("0.6 0.5 1 0.6");

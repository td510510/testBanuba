"use strict";

const makeup = require("./makeup.js");

Object.assign(globalThis, makeup.m);
/* Feel free to add your custom code below */
// set lips shiny color
Lips.shiny("1 0 0.49 1")
// resets lips color
// Lips.clear()
